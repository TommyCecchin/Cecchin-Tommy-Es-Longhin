from flask import Flask,request, url_for, redirect, render_template
import pickle
import numpy as np
import os
app = Flask(__name__)



print("FILE:", os.path.dirname(os.path.realpath(__file__)))
model = pickle.load(open("/Users/tommy/PycharmProjects/eslonghin/venv/modeldef.pkl",'rb'))
print(model)
@app.route('/')
def hello_world():
    return render_template("wind.html")


@app.route('/predict',methods=['POST','GET'])
def predict():
    int_features=[int(x) for x in request.form.values()]
    final=[np.array(int_features)]
    print(int_features)
    print(final)
    prediction=model.predict(final)
    print(prediction)
    output='{0:.{1}f}'.format(prediction[0], 2)

    return '\n The wind was {}'.format(output)
        #return render_template('wind.html',pred='\n Probability of fire occuring is {}'.format(output),bhai="Y")


if __name__ == '__main__':
    app.run(debug=True)

